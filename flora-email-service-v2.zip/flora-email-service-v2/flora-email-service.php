<?php
/**
 * Plugin Name: Flora Email Service
 * Description: Handles email sending for Flora Admin Dashboard
 * Version: 2.0.0
 * Author: Flora Distribution
 */

if (!defined('ABSPATH')) {
    exit;
}

class Flora_Email_Service {
    
    private $from_email = 'lists@floradistro.com';
    private $from_name = 'Flora Distribution';
    
    public function __construct() {
        add_action('rest_api_init', array($this, 'register_routes'));
        add_filter('wp_mail_from', array($this, 'set_from_email'));
        add_filter('wp_mail_from_name', array($this, 'set_from_name'));
        add_filter('wp_mail_content_type', array($this, 'set_content_type'));
    }
    
    public function register_routes() {
        register_rest_route('flora/v1', '/email/send', array(
            'methods' => 'POST',
            'callback' => array($this, 'send_email'),
            'permission_callback' => '__return_true', // Allow all requests (we check auth inside)
        ));
    }
    
    public function send_email($request) {
        // Check authentication
        $auth_check = $this->check_auth($request);
        if (is_wp_error($auth_check)) {
            return $auth_check;
        }
        
        $params = $request->get_json_params();
        
        $to = isset($params['to']) ? $params['to'] : '';
        $subject = isset($params['subject']) ? $params['subject'] : '';
        $message = isset($params['message']) ? $params['message'] : '';
        
        if (empty($to) || empty($subject) || empty($message)) {
            return new WP_Error(
                'missing_parameters',
                'Missing required parameters: to, subject, message',
                array('status' => 400)
            );
        }
        
        // Parse recipients
        $recipients = array_map('trim', explode(',', $to));
        $recipients = array_filter($recipients, function($email) {
            return is_email($email);
        });
        
        if (empty($recipients)) {
            return new WP_Error(
                'invalid_recipients',
                'No valid email addresses provided',
                array('status' => 400)
            );
        }
        
        // Prepare headers
        $email_headers = array(
            'Content-Type: text/html; charset=UTF-8',
            'From: ' . $this->from_name . ' <' . $this->from_email . '>'
        );
        
        // Send email
        $sent = wp_mail($recipients, $subject, $message, $email_headers);
        
        if (!$sent) {
            error_log('Flora Email Service: Failed to send email to ' . implode(', ', $recipients));
            
            return new WP_Error(
                'email_failed',
                'Failed to send email. Please check server email configuration.',
                array('status' => 500)
            );
        }
        
        // Log success
        error_log('Flora Email Service: Successfully sent email to ' . implode(', ', $recipients));
        
        return rest_ensure_response(array(
            'success' => true,
            'message' => 'Email sent successfully',
            'recipients' => $recipients,
            'subject' => $subject,
            'timestamp' => current_time('mysql')
        ));
    }
    
    private function check_auth($request) {
        $auth_header = $request->get_header('authorization');
        
        if (!$auth_header) {
            return new WP_Error(
                'no_authorization',
                'Authorization header is required',
                array('status' => 401)
            );
        }
        
        // Check if it's Basic auth
        if (strpos($auth_header, 'Basic ') !== 0) {
            return new WP_Error(
                'invalid_auth_type',
                'Basic authorization required',
                array('status' => 401)
            );
        }
        
        // Decode credentials
        $credentials = base64_decode(substr($auth_header, 6));
        list($key, $secret) = explode(':', $credentials, 2);
        
        // Expected credentials
        $expected_key = 'ck_bb8e5fe3d405e6ed6b8c079c93002d7d8b23a7d5';
        $expected_secret = 'cs_38194e74c7ddc5d72b6c32c70485728e7e529678';
        
        // Verify credentials
        if ($key === $expected_key && $secret === $expected_secret) {
            return true;
        }
        
        return new WP_Error(
            'invalid_credentials',
            'Invalid API credentials',
            array('status' => 401)
        );
    }
    
    public function set_from_email($email) {
        return $this->from_email;
    }
    
    public function set_from_name($name) {
        return $this->from_name;
    }
    
    public function set_content_type($content_type) {
        return 'text/html';
    }
}

// Initialize the plugin
new Flora_Email_Service();

// Optional SMTP configuration
add_action('phpmailer_init', function($phpmailer) {
    if (defined('SMTP_HOST') && defined('SMTP_PORT')) {
        $phpmailer->isSMTP();
        $phpmailer->Host = SMTP_HOST;
        $phpmailer->Port = SMTP_PORT;
        
        if (defined('SMTP_USER') && defined('SMTP_PASS')) {
            $phpmailer->SMTPAuth = true;
            $phpmailer->Username = SMTP_USER;
            $phpmailer->Password = SMTP_PASS;
        }
        
        if (defined('SMTP_SECURE')) {
            $phpmailer->SMTPSecure = SMTP_SECURE;
        }
    }
});

