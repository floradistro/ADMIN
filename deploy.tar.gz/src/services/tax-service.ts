import { SimpleWPAuth } from '../lib/wp-auth-simple';

export interface TaxRate {
  id: number;
  country: string;
  state: string;
  postcode: string;
  city: string;
  rate: string;
  name: string;
  priority: number;
  compound: boolean;
  shipping: boolean;
  order: number;
  class: string;
  postcodes?: string[];
  cities?: string[];
}

export interface TaxClass {
  slug: string;
  name: string;
}

export interface CreateTaxRateData {
  country?: string;
  state?: string;
  postcode?: string;
  city?: string;
  rate: string;
  name: string;
  priority?: number;
  compound?: boolean;
  shipping?: boolean;
  order?: number;
  class?: string;
  postcodes?: string[];
  cities?: string[];
}

export interface UpdateTaxRateData extends Partial<CreateTaxRateData> {
  id: number;
}

export interface LocationTaxMapping {
  location_id: number;
  tax_rate_id: number;
  is_default: boolean;
  created_at: string;
  updated_at: string;
}

class TaxService {
  private baseUrl: string;
  private auth: SimpleWPAuth;
  private consumerKey: string;
  private consumerSecret: string;

  constructor() {
    this.baseUrl = 'https://api.floradistro.com';
    this.auth = new SimpleWPAuth();
    this.consumerKey = 'ck_bb8e5fe3d405e6ed6b8c079c93002d7d8b23a7d5';
    this.consumerSecret = 'cs_38194e74c7ddc5d72b6c32c70485728e7e529678';
  }

  /**
   * Get all tax rates from WooCommerce
   */
  async getTaxRates(params?: {
    page?: number;
    per_page?: number;
    search?: string;
    class?: string;
  }): Promise<TaxRate[]> {
    try {
      const queryParams = new URLSearchParams();
      if (params?.page) queryParams.append('page', params.page.toString());
      if (params?.per_page) queryParams.append('per_page', params.per_page.toString());
      if (params?.search) queryParams.append('search', params.search);
      if (params?.class) queryParams.append('class', params.class);

      const url = `${this.baseUrl}/wp-json/wc/v3/taxes${queryParams.toString() ? '?' + queryParams.toString() : ''}`;
      
      const response = await fetch(url, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Basic ${btoa(`${this.consumerKey}:${this.consumerSecret}`)}`
        }
      });

      if (!response.ok) {
        throw new Error(`Failed to fetch tax rates: ${response.statusText}`);
      }

      const data = await response.json();
      return data;
    } catch (error) {
      throw error;
    }
  }

  /**
   * Get a single tax rate by ID
   */
  async getTaxRate(id: number): Promise<TaxRate> {
    try {
      const url = `${this.baseUrl}/wp-json/wc/v3/taxes/${id}`;
      
      const response = await fetch(url, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Basic ${btoa(`${this.consumerKey}:${this.consumerSecret}`)}`
        }
      });

      if (!response.ok) {
        throw new Error(`Failed to fetch tax rate: ${response.statusText}`);
      }

      const data = await response.json();
      return data;
    } catch (error) {
      throw error;
    }
  }

  /**
   * Create a new tax rate
   */
  async createTaxRate(taxData: CreateTaxRateData): Promise<TaxRate> {
    try {
      const url = `${this.baseUrl}/wp-json/wc/v3/taxes`;
      
      const response = await fetch(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Basic ${btoa(`${this.consumerKey}:${this.consumerSecret}`)}`
        },
        body: JSON.stringify(taxData)
      });

      if (!response.ok) {
        throw new Error(`Failed to create tax rate: ${response.statusText}`);
      }

      const data = await response.json();
      return data;
    } catch (error) {
      throw error;
    }
  }

  /**
   * Update an existing tax rate
   */
  async updateTaxRate(id: number, taxData: Partial<CreateTaxRateData>): Promise<TaxRate> {
    try {
      const url = `${this.baseUrl}/wp-json/wc/v3/taxes/${id}`;
      
      const response = await fetch(url, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Basic ${btoa(`${this.consumerKey}:${this.consumerSecret}`)}`
        },
        body: JSON.stringify(taxData)
      });

      if (!response.ok) {
        throw new Error(`Failed to update tax rate: ${response.statusText}`);
      }

      const data = await response.json();
      return data;
    } catch (error) {
      throw error;
    }
  }

  /**
   * Delete a tax rate
   */
  async deleteTaxRate(id: number): Promise<TaxRate> {
    try {
      const url = `${this.baseUrl}/wp-json/wc/v3/taxes/${id}?force=true`;
      
      const response = await fetch(url, {
        method: 'DELETE',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Basic ${btoa(`${this.consumerKey}:${this.consumerSecret}`)}`
        }
      });

      if (!response.ok) {
        throw new Error(`Failed to delete tax rate: ${response.statusText}`);
      }

      const data = await response.json();
      return data;
    } catch (error) {
      throw error;
    }
  }

  /**
   * Get all tax classes
   */
  async getTaxClasses(): Promise<TaxClass[]> {
    try {
      const url = `${this.baseUrl}/wp-json/wc/v3/taxes/classes`;
      
      const response = await fetch(url, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Basic ${btoa(`${this.consumerKey}:${this.consumerSecret}`)}`
        }
      });

      if (!response.ok) {
        throw new Error(`Failed to fetch tax classes: ${response.statusText}`);
      }

      const data = await response.json();
      return data;
    } catch (error) {
      throw error;
    }
  }

  /**
   * Batch create/update/delete tax rates
   */
  async batchTaxRates(data: {
    create?: CreateTaxRateData[];
    update?: UpdateTaxRateData[];
    delete?: number[];
  }): Promise<{
    create: TaxRate[];
    update: TaxRate[];
    delete: TaxRate[];
  }> {
    try {
      const url = `${this.baseUrl}/wp-json/wc/v3/taxes/batch`;
      
      const response = await fetch(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Basic ${btoa(`${this.consumerKey}:${this.consumerSecret}`)}`
        },
        body: JSON.stringify(data)
      });

      if (!response.ok) {
        throw new Error(`Failed to batch update tax rates: ${response.statusText}`);
      }

      const result = await response.json();
      return result;
    } catch (error) {
      throw error;
    }
  }

  /**
   * Get location-tax mappings (custom implementation)
   */
  async getLocationTaxMappings(locationId?: number): Promise<LocationTaxMapping[]> {
    try {
      const url = locationId 
        ? `/api/flora/locations/${locationId}/taxes`
        : '/api/flora/locations/taxes';
      
      const response = await fetch(url, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          'Cache-Control': 'no-cache, no-store, must-revalidate',
          'Pragma': 'no-cache',
          'Expires': '0'
        },
        cache: 'no-store'
      });

      if (!response.ok) {
        throw new Error(`Failed to fetch location tax mappings: ${response.statusText}`);
      }

      const data = await response.json();
      
      // Convert string IDs to numbers to match interface
      return data.map((mapping: any) => ({
        ...mapping,
        location_id: parseInt(mapping.location_id),
        tax_rate_id: parseInt(mapping.tax_rate_id),
        is_default: mapping.is_default === '1' || mapping.is_default === 1 || mapping.is_default === true
      }));
    } catch (error) {
      throw error;
    }
  }

  /**
   * Assign tax rate to location
   */
  async assignTaxToLocation(locationId: number, taxRateId: number, isDefault: boolean = false): Promise<LocationTaxMapping> {
    try {
      const url = `/api/flora/locations/${locationId}/taxes`;
      
      const response = await fetch(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          tax_rate_id: taxRateId,
          is_default: isDefault
        })
      });

      if (!response.ok) {
        throw new Error(`Failed to assign tax to location: ${response.statusText}`);
      }

      const data = await response.json();
      return data;
    } catch (error) {
      throw error;
    }
  }

  /**
   * Remove tax rate from location
   */
  async removeTaxFromLocation(locationId: number, taxRateId: number): Promise<void> {
    try {
      const url = `/api/flora/locations/${locationId}/taxes/${taxRateId}`;
      
      const response = await fetch(url, {
        method: 'DELETE',
        headers: {
          'Content-Type': 'application/json',
          'Cache-Control': 'no-cache, no-store, must-revalidate',
          'Pragma': 'no-cache',
          'Expires': '0'
        },
        cache: 'no-store'
      });

      if (!response.ok) {
        throw new Error(`Failed to remove tax from location: ${response.statusText}`);
      }
    } catch (error) {
      throw error;
    }
  }

  /**
   * Get tax rates for a specific location
   */
  async getTaxRatesForLocation(locationId: number): Promise<TaxRate[]> {
    try {
      const mappings = await this.getLocationTaxMappings(locationId);
      const taxRateIds = mappings.map(m => m.tax_rate_id);
      
      if (taxRateIds.length === 0) {
        return [];
      }

      // Fetch all tax rates and filter by IDs
      const allTaxRates = await this.getTaxRates({ per_page: 100 });
      return allTaxRates.filter(rate => taxRateIds.includes(rate.id));
    } catch (error) {
      throw error;
    }
  }
}

export const taxService = new TaxService();