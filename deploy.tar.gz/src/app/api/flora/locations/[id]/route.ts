import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';

const FLORA_API_URL = 'https://api.floradistro.com';
const WC_CONSUMER_KEY = 'ck_bb8e5fe3d405e6ed6b8c079c93002d7d8b23a7d5';
const WC_CONSUMER_SECRET = 'cs_38194e74c7ddc5d72b6c32c70485728e7e529678';

// Import the same in-memory storage (this is a simple approach - in production would use Redis/DB)
declare global {
  var locationUpdates: { [key: string]: any };
}

if (!global.locationUpdates) {
  global.locationUpdates = {};
}

export async function PUT(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const session = await getServerSession(authOptions);
    if (!session) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const body = await request.json();
    const { id: locationId } = await params;
    
    
    // Call Flora API to update location
    const floraApiUrl = `${FLORA_API_URL}/wp-json/flora-im/v1/locations/${locationId}?consumer_key=${WC_CONSUMER_KEY}&consumer_secret=${WC_CONSUMER_SECRET}`;
    
    const floraResponse = await fetch(floraApiUrl, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(body),
    });

    if (!floraResponse.ok) {
      const errorText = await floraResponse.text();
      return NextResponse.json({ 
        error: `Failed to update location in Flora API: ${floraResponse.status}` 
      }, { status: floraResponse.status });
    }

    const floraResult = await floraResponse.json();
    
    // Clear any cached updates for this location since we've successfully updated via API
    if (global.locationUpdates && global.locationUpdates[locationId]) {
      delete global.locationUpdates[locationId];
    }
    
    return NextResponse.json({
      success: true,
      data: floraResult.data,
      message: 'Location updated successfully'
    });
  } catch (error) {
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

export async function DELETE(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const session = await getServerSession(authOptions);
    if (!session) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }
    
    const { id: locationId } = await params;
    
    // For now, simulate the delete operation
    // TODO: Implement actual Flora IM location deletion via direct database or custom endpoint
    
    // Check if it's a default location (simulate)
    if (locationId === '1') {
      return NextResponse.json({ 
        error: 'Cannot delete default location' 
      }, { status: 400 });
    }
    
    return NextResponse.json({
      success: true,
      message: 'Location deleted successfully'
    });
  } catch (error) {
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}