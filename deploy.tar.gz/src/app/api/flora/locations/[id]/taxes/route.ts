import { NextRequest, NextResponse } from 'next/server';
import { SimpleWPAuth } from '../../../../../../lib/wp-auth-simple';

const API_BASE = 'https://api.floradistro.com';

// GET /api/flora/locations/[id]/taxes - Get tax mappings for a specific location
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const locationId = parseInt(id);

    // Use Magic2 API to get tax rates for location
    const url = `${API_BASE}/wp-json/flora-im/v1/locations/${locationId}/taxes`;
    const urlParams = new URLSearchParams({
      consumer_key: 'ck_bb8e5fe3d405e6ed6b8c079c93002d7d8b23a7d5',
      consumer_secret: 'cs_38194e74c7ddc5d72b6c32c70485728e7e529678'
    });

    const response = await fetch(`${url}?${urlParams.toString()}`, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        'Cache-Control': 'no-cache, no-store, must-revalidate',
        'Pragma': 'no-cache',
        'Expires': '0'
      },
      cache: 'no-store'
    });

    if (!response.ok) {
      throw new Error(`Magic2 API error: ${response.status} ${response.statusText}`);
    }

    const data = await response.json();
    return NextResponse.json(data, {
      headers: {
        'Cache-Control': 'no-store, max-age=0',
        'Pragma': 'no-cache',
        'Expires': '0'
      }
    });
  } catch (error) {
    return NextResponse.json(
      { error: 'Failed to fetch location tax mappings' },
      { status: 500 }
    );
  }
}

// POST /api/flora/locations/[id]/taxes - Assign tax rate to location
export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const locationId = parseInt(id);
    const body = await request.json();
    const { tax_rate_id, is_default = false } = body;

    if (!tax_rate_id) {
      return NextResponse.json(
        { error: 'tax_rate_id is required' },
        { status: 400 }
      );
    }

    // Use Magic2 API to assign tax to location
    const url = `${API_BASE}/wp-json/flora-im/v1/locations/${locationId}/taxes`;
    const urlParams = new URLSearchParams({
      consumer_key: 'ck_bb8e5fe3d405e6ed6b8c079c93002d7d8b23a7d5',
      consumer_secret: 'cs_38194e74c7ddc5d72b6c32c70485728e7e529678'
    });

    const response = await fetch(`${url}?${urlParams.toString()}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Cache-Control': 'no-cache, no-store, must-revalidate',
        'Pragma': 'no-cache',
        'Expires': '0'
      },
      body: JSON.stringify({
        tax_rate_id: parseInt(tax_rate_id),
        is_default: Boolean(is_default)
      }),
      cache: 'no-store'
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      throw new Error(`Magic2 API error: ${response.status} ${response.statusText} - ${errorData.message || 'Unknown error'}`);
    }

    const data = await response.json();

    return NextResponse.json(data, { 
      status: 201,
      headers: {
        'Cache-Control': 'no-store, max-age=0',
        'Pragma': 'no-cache',
        'Expires': '0'
      }
    });
  } catch (error) {
    return NextResponse.json(
      { error: 'Failed to assign tax to location' },
      { status: 500 }
    );
  }
}