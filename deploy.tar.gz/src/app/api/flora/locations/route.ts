import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';

const FLORA_API_URL = 'https://api.floradistro.com';
const WC_CONSUMER_KEY = 'ck_bb8e5fe3d405e6ed6b8c079c93002d7d8b23a7d5';
const WC_CONSUMER_SECRET = 'cs_38194e74c7ddc5d72b6c32c70485728e7e529678';


export async function GET(request: NextRequest) {
  try {
    // TODO: Re-enable authentication in production
    // For development, bypass auth to allow locations to load
    // const session = await getServerSession(authOptions);
    // if (!session) {
    //   return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    // }

    // Call the Flora IM plugin API with cache busting always enabled
    const url = `${FLORA_API_URL}/wp-json/flora-im/v1/locations?consumer_key=${WC_CONSUMER_KEY}&consumer_secret=${WC_CONSUMER_SECRET}&_t=${Date.now()}`;
    const response = await fetch(url, {
      headers: {
        'Content-Type': 'application/json',
        'Cache-Control': 'no-cache, no-store, must-revalidate',
        'Pragma': 'no-cache',
        'Expires': '0'
      },
      // Always use no-store to avoid any caching
      cache: 'no-store',
    });
    
    if (!response.ok) {
      const errorText = await response.text();
      return NextResponse.json({ error: `Failed to fetch locations: ${response.status}` }, { status: response.status });
    }

    let floraLocations = await response.json();
    
    // Also fetch custom locations created via WordPress
    try {
      const customLocations = await getCustomLocations();
      
      // Combine Flora locations with custom locations
      const allLocations = [...floraLocations, ...customLocations];
      
      return NextResponse.json({
        success: true,
        data: allLocations
      }, {
        headers: {
          'Cache-Control': 'no-store, max-age=0',
          'Pragma': 'no-cache',
          'Expires': '0'
        }
      });
    } catch (customError) {
      console.log('Error fetching custom locations:', customError);
      // Return just Flora locations if custom locations fail
      return NextResponse.json({
        success: true,
        data: floraLocations
      }, {
        headers: {
          'Cache-Control': 'no-store, max-age=0',
          'Pragma': 'no-cache',
          'Expires': '0'
        }
      });
    }
  } catch (error) {
    console.error('Error fetching locations from Flora API:', error);
    return NextResponse.json({ 
      error: 'Failed to fetch locations from Flora API',
      details: error instanceof Error ? error.message : 'Unknown error'
    }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    console.log('Creating location via direct database insertion:', body);

    // Since Flora IM doesn't support location creation via API, 
    // we'll create it directly in the WordPress database using WooCommerce API
    return await createLocationDirectly(body);
  } catch (error) {
    console.error('Error creating location:', error);
    return NextResponse.json({ 
      error: 'Failed to create location',
      details: error instanceof Error ? error.message : 'Unknown error'
    }, { status: 500 });
  }
}

// Get custom locations created via WordPress
async function getCustomLocations() {
  try {
    const customLocations = [];
    
    // First, try to get locations from WooCommerce shipping zones
    try {
      const zonesResponse = await fetch('https://api.floradistro.com/wp-json/wc/v3/shipping/zones', {
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Basic ${Buffer.from(`${WC_CONSUMER_KEY}:${WC_CONSUMER_SECRET}`).toString('base64')}`
        }
      });
      
      if (zonesResponse.ok) {
        const zones = await zonesResponse.json();
        console.log('Found WC shipping zones:', zones.length);
        
        // Transform shipping zones to location format
        zones.forEach((zone: any) => {
          if (zone.name && zone.name !== 'Locations not covered by your other zones') {
            customLocations.push({
              id: `wc_zone_${zone.id}`,
              name: zone.name,
              phone: '',
              email: '',
              description: '',
              address_line_1: '',
              address_line_2: '',
              city: '',
              state: '',
              postal_code: '',
              country: 'US',
              is_active: '1',
              is_default: '0',
              priority: zone.order || 0,
              status: 'active',
              created_at: new Date().toISOString(),
              updated_at: new Date().toISOString(),
              source: 'wc_shipping_zone'
            });
          }
        });
      }
    } catch (error) {
      console.log('Failed to fetch WC shipping zones:', error);
    }
    
    // Also try to get locations from WordPress posts with flora_location_type meta
    try {
      const postsResponse = await fetch('https://api.floradistro.com/wp-json/wp/v2/posts?meta_key=flora_location_type&meta_value=location', {
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Basic ${Buffer.from(`${WC_CONSUMER_KEY}:${WC_CONSUMER_SECRET}`).toString('base64')}`
        }
      });
      
      if (postsResponse.ok) {
        const posts = await postsResponse.json();
        console.log('Found WordPress location posts:', posts.length);
        
        // Transform posts to location format
        for (const post of posts) {
          customLocations.push({
            id: `wp_post_${post.id}`,
            name: post.title?.rendered || 'Unnamed Location',
            phone: post.meta?.flora_location_phone || '',
            email: post.meta?.flora_location_email || '',
            description: post.content?.rendered || post.meta?.flora_location_description || '',
            address_line_1: post.meta?.flora_location_address_1 || '',
            address_line_2: post.meta?.flora_location_address_2 || '',
            city: post.meta?.flora_location_city || '',
            state: post.meta?.flora_location_state || '',
            postal_code: post.meta?.flora_location_postal_code || '',
            country: post.meta?.flora_location_country || 'US',
            is_active: post.meta?.flora_location_is_active || '1',
            is_default: post.meta?.flora_location_is_default || '0',
            priority: parseInt(post.meta?.flora_location_priority || '0'),
            status: post.meta?.flora_location_status || 'active',
            created_at: post.date,
            updated_at: post.modified,
            source: 'wp_post'
          });
        }
      }
    } catch (error) {
      console.log('Failed to fetch WordPress location posts:', error);
    }
    
    console.log(`Found ${customLocations.length} custom locations total`);
    return customLocations;
  } catch (error) {
    console.error('Error fetching custom locations:', error);
    return [];
  }
}

// Create location directly by inserting into Flora IM plugin tables
async function createLocationDirectly(locationData: any) {
  try {
    console.log('Attempting direct Flora IM location creation:', locationData);
    
    // Try using WooCommerce REST API to create location data
    // This approach simulates what Flora IM plugin would do internally
    const wpUrl = 'https://api.floradistro.com/wp-json/wc/v3';
    
    // First, try to create it as a WooCommerce store location or similar
    const locationPayload = {
      name: locationData.name,
      description: locationData.description || '',
      meta_data: [
        { key: '_flora_location_phone', value: locationData.phone || '' },
        { key: '_flora_location_email', value: locationData.email || '' },
        { key: '_flora_location_address_1', value: locationData.address_line_1 || '' },
        { key: '_flora_location_address_2', value: locationData.address_line_2 || '' },
        { key: '_flora_location_city', value: locationData.city || '' },
        { key: '_flora_location_state', value: locationData.state || '' },
        { key: '_flora_location_postal_code', value: locationData.postal_code || '' },
        { key: '_flora_location_country', value: locationData.country || 'US' },
        { key: '_flora_location_is_active', value: locationData.is_active || '1' },
        { key: '_flora_location_is_default', value: locationData.is_default || '0' },
        { key: '_flora_location_priority', value: locationData.priority || 0 },
        { key: '_flora_location_status', value: locationData.status || 'active' }
      ]
    };

    // Try creating as a WooCommerce shipping zone first (closest to location concept)
    let wpResponse = await fetch(`${wpUrl}/shipping/zones`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Basic ${Buffer.from(`${WC_CONSUMER_KEY}:${WC_CONSUMER_SECRET}`).toString('base64')}`
      },
      body: JSON.stringify({
        name: locationData.name,
        order: locationData.priority || 0
      })
    });

    if (!wpResponse.ok) {
      console.log('WC Shipping zones failed, trying custom post approach...');
      
      // Fallback: Create as a custom post
      wpResponse = await fetch('https://api.floradistro.com/wp-json/wp/v2/posts', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Basic ${Buffer.from(`${WC_CONSUMER_KEY}:${WC_CONSUMER_SECRET}`).toString('base64')}`
        },
        body: JSON.stringify({
          title: locationData.name,
          content: locationData.description || '',
          status: 'publish',
          meta: {
            flora_location_type: 'location',
            flora_location_phone: locationData.phone || '',
            flora_location_email: locationData.email || '',
            flora_location_address_1: locationData.address_line_1 || '',
            flora_location_address_2: locationData.address_line_2 || '',
            flora_location_city: locationData.city || '',
            flora_location_state: locationData.state || '',
            flora_location_postal_code: locationData.postal_code || '',
            flora_location_country: locationData.country || 'US',
            flora_location_is_active: locationData.is_active || '1',
            flora_location_is_default: locationData.is_default || '0',
            flora_location_priority: locationData.priority || 0,
            flora_location_status: locationData.status || 'active'
          }
        })
      });
    }

    if (!wpResponse.ok) {
      const errorText = await wpResponse.text();
      console.error('WordPress API error:', wpResponse.status, errorText);
      throw new Error(`WordPress API error: ${wpResponse.status}`);
    }

    const wpData = await wpResponse.json();
    console.log('WordPress creation successful:', wpData);
    
    // Generate a high ID to avoid conflicts with existing Flora locations
    const newId = Date.now(); // Use timestamp as unique ID
    
    // Transform response to Flora location format
    const floraLocation = {
      id: newId,
      name: locationData.name,
      phone: locationData.phone || '',
      email: locationData.email || '',
      description: locationData.description || '',
      address_line_1: locationData.address_line_1 || '',
      address_line_2: locationData.address_line_2 || '',
      city: locationData.city || '',
      state: locationData.state || '',
      postal_code: locationData.postal_code || '',
      country: locationData.country || 'US',
      is_active: locationData.is_active || '1',
      is_default: locationData.is_default || '0',
      priority: locationData.priority || 0,
      status: locationData.status || 'active',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
      wp_post_id: wpData.id // Store reference to WordPress post
    };

    console.log('Created Flora location:', floraLocation);

    return NextResponse.json({
      success: true,
      data: floraLocation,
      message: 'Location created successfully via WordPress API'
    });
  } catch (error) {
    console.error('Direct WordPress creation failed:', error);
    return NextResponse.json({ 
      error: 'Failed to create location via WordPress API',
      details: error instanceof Error ? error.message : 'Unknown error'
    }, { status: 500 });
  }
}