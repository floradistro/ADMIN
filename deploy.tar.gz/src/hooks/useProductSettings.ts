'use client';

import { useState, useCallback, useEffect } from 'react';

export interface ProductDisplaySettings {
  viewMode: 'grid' | 'table';
  productsPerPage: 20 | 50 | 100;
  showProductImages: boolean;
}

export interface InventorySettings {
  lowStockThreshold: number;
  autoRefreshInventory: boolean;
  showStockLevels: boolean;
}

export interface CategoryFilterSettings {
  enableCategoryFiltering: boolean;
  showEmptyCategories: boolean;
}

export interface ProductSettingsState {
  display: ProductDisplaySettings;
  inventory: InventorySettings;
  categoryFilters: CategoryFilterSettings;
}

const DEFAULT_SETTINGS: ProductSettingsState = {
  display: {
    viewMode: 'grid',
    productsPerPage: 20,
    showProductImages: true,
  },
  inventory: {
    lowStockThreshold: 10,
    autoRefreshInventory: true,
    showStockLevels: true,
  },
  categoryFilters: {
    enableCategoryFiltering: true,
    showEmptyCategories: false,
  },
};

export function useProductSettings() {
  const [settings, setSettings] = useState<ProductSettingsState>(DEFAULT_SETTINGS);
  const [isLoading, setIsLoading] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Initialize with default settings
  useEffect(() => {
    setIsLoading(true);
    try {
      // Use default settings - no persistence needed
      setSettings(DEFAULT_SETTINGS);
      // TODO: Load from API when endpoint is available
    } catch (err) {
      setError('Failed to load settings');
    } finally {
      setIsLoading(false);
    }
  }, []);

  const updateDisplaySettings = useCallback((updates: Partial<ProductDisplaySettings>) => {
    setSettings(prev => ({
      ...prev,
      display: { ...prev.display, ...updates }
    }));
  }, []);

  const updateInventorySettings = useCallback((updates: Partial<InventorySettings>) => {
    setSettings(prev => ({
      ...prev,
      inventory: { ...prev.inventory, ...updates }
    }));
  }, []);

  const updateCategoryFilterSettings = useCallback((updates: Partial<CategoryFilterSettings>) => {
    setSettings(prev => ({
      ...prev,
      categoryFilters: { ...prev.categoryFilters, ...updates }
    }));
  }, []);

  const saveSettings = useCallback(async () => {
    setIsSaving(true);
    setError(null);
    try {
      // Settings are temporary - no persistence needed in dev mode
      // TODO: Save to API when endpoint is available
      return { success: true };
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to save settings';
      setError(errorMessage);
      return { success: false, error: errorMessage };
    } finally {
      setIsSaving(false);
    }
  }, [settings]);

  const resetSettings = useCallback(() => {
    setSettings(DEFAULT_SETTINGS);
  }, []);

  return {
    settings,
    isLoading,
    isSaving,
    error,
    updateDisplaySettings,
    updateInventorySettings,
    updateCategoryFilterSettings,
    saveSettings,
    resetSettings,
  };
}