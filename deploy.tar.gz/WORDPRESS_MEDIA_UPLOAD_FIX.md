# WordPress Media Upload Fix for Production (Vercel)

## The Problem
WordPress Media uploads were failing on the live Vercel site because WooCommerce API keys (`WP_CONSUMER_KEY` and `WP_CONSUMER_SECRET`) cannot be used for WordPress Media API authentication. The WordPress REST API requires WordPress user authentication for media uploads.

## The Solution
Use WordPress Application Passwords, which is the official recommended method for REST API authentication.

## Setup Instructions

### Step 1: Create a WordPress Application Password

1. **Log in to your WordPress Admin Dashboard**
   - Go to: https://api.floradistro.com/wp-admin

2. **Navigate to Your User Profile**
   - Click on "Users" → "Profile" (or "Your Profile")

3. **Create an Application Password**
   - Scroll down to the "Application Passwords" section
   - Enter a name for this password (e.g., "Portal Admin Media Upload")
   - Click "Add New Application Password"
   - **IMPORTANT**: Copy the generated password immediately (it won't be shown again!)
   - The password will look something like: `xxxx xxxx xxxx xxxx xxxx xxxx` (remove spaces when using)

### Step 2: Add Environment Variables to Vercel

1. **Go to your Vercel Dashboard**
   - Navigate to your project
   - Go to "Settings" → "Environment Variables"

2. **Add these REQUIRED variables:**

```bash
# WordPress Authentication (REQUIRED for media upload)
WP_USERNAME=your_wordpress_username
WP_APP_PASSWORD=your_application_password_without_spaces

# WordPress API Base (REQUIRED)
FLORA_API_BASE=https://api.floradistro.com/wp-json

# WooCommerce API Keys (REQUIRED for product/order data)
WP_CONSUMER_KEY=ck_bb8e5fe3d405e6ed6b8c079c93002d7d8b23a7d5
WP_CONSUMER_SECRET=cs_38194e74c7ddc5d72b6c32c70485728e7e529678

# NextAuth (REQUIRED for login)
NEXTAUTH_URL=https://your-vercel-app.vercel.app
NEXTAUTH_SECRET=your-secret-key-here

# AI Services (OPTIONAL but recommended)
REMOVE_BG_API_KEY=CTYgh57QAP1FvqrEAHAwzFqG
CLIPDROP_API_KEY=b98ecf3e655c977c4102d339c1cef10b7ceeb3484929d3b0c38a1d670c4200450e97261f8e311bcf096aa5c73e0b6547
```

3. **Select all environments:**
   - ✅ Production
   - ✅ Preview  
   - ✅ Development

4. **Save and Redeploy**
   - Click "Save"
   - Trigger a new deployment for changes to take effect

### Step 3: Verify Setup

After deployment, test the media upload:
1. Log in to your Portal Admin
2. Go to the Media section
3. Try uploading an image
4. Check if it appears in both:
   - Your Portal Admin media library
   - WordPress Media Library (https://api.floradistro.com/wp-admin/upload.php)

## Alternative Authentication Methods

If Application Passwords don't work, you can try:

### Option 1: WordPress User Password (Less Secure)
```bash
WP_USERNAME=your_wordpress_username
WP_USER_PASSWORD=your_actual_wordpress_password
```
⚠️ **Warning**: This is less secure than Application Passwords

### Option 2: JWT Authentication (Requires Plugin)
1. Install JWT Authentication plugin on WordPress
2. Generate a JWT token
3. Add to Vercel:
```bash
WP_JWT_TOKEN=your_jwt_token_here
```

## Troubleshooting

### "rest_cannot_create" Error
- Your WordPress user doesn't have media upload permissions
- Solution: Make sure the user is an Administrator or has 'upload_files' capability

### "invalid_username" Error  
- The WP_USERNAME environment variable is not set or incorrect
- Solution: Double-check the username in Vercel environment variables

### "Wrong number of segments" Error
- The Application Password format is incorrect
- Solution: Remove all spaces from the Application Password

### Images Save Locally but Not in WordPress
- This means authentication is failing but the app is falling back to local storage
- Local storage doesn't persist on Vercel (serverless environment)
- Solution: Fix WordPress authentication using the steps above

## Testing Locally

Add to your `.env.local`:
```bash
WP_USERNAME=your_wordpress_username
WP_APP_PASSWORD=your_application_password_without_spaces
```

Then restart your dev server:
```bash
npm run dev
```

## Security Notes

1. **Application Passwords are the most secure option** for API access
2. Each Application Password can be revoked independently
3. Never commit credentials to your repository
4. Always use environment variables for sensitive data

## Need Help?

If uploads still fail after following these steps:
1. Check the browser console for errors
2. Check Vercel function logs for detailed error messages
3. Verify your WordPress user has Administrator role
4. Ensure WordPress REST API is accessible at https://api.floradistro.com/wp-json
