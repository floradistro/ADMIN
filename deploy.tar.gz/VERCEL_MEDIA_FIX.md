# Media Manager Fix for Vercel Deployment

## Issues Found and Fixed

### 1. **CRITICAL BUG: Hard-Coded API Credentials**
- **Location**: `/api/media/library/route.ts`
- **Problem**: WordPress API credentials were hard-coded, overriding environment variables
- **Status**: ✅ FIXED - Now properly uses environment variables

### 2. **WordPress API Authentication Failures**
- **Problem**: Single authentication method that doesn't work with WordPress REST API
- **Status**: ✅ FIXED - Created robust client with multiple auth methods:
  - OAuth 1.0a style
  - Basic Authentication
  - Query Parameters (WooCommerce style)
  - Bearer Token
  - Application Passwords (if configured)

### 3. **Serverless Environment Issues**
- **Problem**: No fallback when WordPress API fails on Vercel
- **Status**: ✅ FIXED - Better error handling and debugging

## Required Vercel Environment Variables

You MUST set these environment variables in your Vercel project settings:

```bash
# WordPress API Credentials (REQUIRED)
WP_CONSUMER_KEY=ck_bb8e5fe3d405e6ed6b8c079c93002d7d8b23a7d5
WP_CONSUMER_SECRET=cs_38194e74c7ddc5d72b6c32c70485728e7e529678
FLORA_API_BASE=https://api.floradistro.com/wp-json

# Optional but recommended for better authentication
WP_USERNAME=your_wordpress_username
WP_APP_PASSWORD=your_application_password

# NextAuth Configuration (REQUIRED)
NEXTAUTH_URL=https://your-vercel-domain.vercel.app
NEXTAUTH_SECRET=your-secret-key

# Optional AI Services
REMOVE_BG_API_KEY=your_remove_bg_key
CLIPDROP_API_KEY=your_clipdrop_key
```

## How to Add Environment Variables to Vercel

1. Go to your Vercel Dashboard
2. Select your project
3. Go to **Settings** → **Environment Variables**
4. Add each variable with the correct value
5. **IMPORTANT**: Make sure to select the correct environments:
   - ✅ Production
   - ✅ Preview
   - ✅ Development

## Testing the Fix

### 1. Debug Endpoint
Visit: `https://your-domain.vercel.app/api/media/debug`
(You must be logged in)

This will show you:
- Environment configuration
- WordPress API connection status
- Available credentials
- File system permissions

### 2. Test Upload
1. Go to any product in the admin
2. Try uploading an image
3. Check browser console for detailed logs

### 3. Test Delete
1. Open Media Library
2. Try deleting an image
3. Check browser console for logs

## WordPress API Requirements

Make sure your WordPress site allows REST API access:

1. **Check .htaccess**: Ensure REST API is not blocked
2. **Check Plugins**: Disable any security plugins that might block API access
3. **CORS Headers**: WordPress should allow requests from your Vercel domain

## If Still Not Working

1. **Check the debug endpoint** first to see what's missing
2. **Verify environment variables** are set correctly in Vercel
3. **Check WordPress logs** for authentication failures
4. **Contact WordPress hosting** to ensure API access is enabled

## Files Modified

- `/src/app/api/media/upload/route.ts` - Fixed upload authentication
- `/src/app/api/media/delete/route.ts` - Fixed delete authentication  
- `/src/app/api/media/library/route.ts` - Removed hard-coded credentials
- `/src/lib/wp-media-client.ts` - NEW: Robust WordPress API client
- `/src/app/api/media/debug/route.ts` - NEW: Debug endpoint

## Deployment

After setting environment variables:

```bash
git add .
git commit -m "Fix media manager for Vercel deployment"
git push origin main
```

Vercel will automatically deploy with the new environment variables.
